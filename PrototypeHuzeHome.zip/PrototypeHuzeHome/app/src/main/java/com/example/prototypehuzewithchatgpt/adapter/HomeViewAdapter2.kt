package com.example.prototypehuzewithchatgpt.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.prototypehuzewithchatgpt.R
import com.example.prototypehuzewithchatgpt.databinding.ItemCatsBinding
import com.example.prototypehuzewithchatgpt.network.response.CatsItem


class HomeViewAdapter2(private val listCats: List<CatsItem>) :
    RecyclerView.Adapter<HomeViewAdapter2.ViewHolder>() {

    private lateinit var onClickListener: OnClickListener

    class ViewHolder(var binding: ItemCatsBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemCatsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cats = listCats[position]

        holder.apply {
            binding.apply {
                tvRas.text =cats.breed
                Glide.with(itemView.context)
                    .load(cats.image)
                    .error(R.drawable.logohuze)
                    .into(ivCats)


                itemView.setOnClickListener {
                    onClickListener.onItemClick(cats)
                }
            }
        }
    }
    override fun getItemCount(): Int = listCats.size

    fun onItemClick(onClickListener: OnClickListener)
    {
        this.onClickListener = onClickListener
    }

    interface OnClickListener
    {
        fun onItemClick(item: CatsItem)
    }

}