package com.example.prototypehuzewithchatgpt.network.api


import com.example.prototypehuzewithchatgpt.network.response.CatsResponse
import com.example.prototypehuzewithchatgpt.network.response.DogsResponse
import retrofit2.Call
import retrofit2.http.GET


interface ApiService {
    @GET ("dogs")
    fun getDogs(): Call<DogsResponse>
    @GET("cats")
    fun getCats(): Call<CatsResponse>
}