package com.bangkitc23ps404.huze.data.local.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase



//@Database(entities = [HuzeEntity::class], version = 1, exportSchema = false)
//abstract class HuzeRoomDatabase: RoomDatabase() {
//    abstract fun huzeDao(): HuzeDao
//
//    companion object{
//        @Volatile
//        private var INSTANCE: HuzeRoomDatabase? = null
//
//        @JvmStatic
//        fun getDatabase(context: Context): HuzeRoomDatabase{
//            if(INSTANCE == null) {
//                synchronized(HuzeRoomDatabase::class.java) {
//                    INSTANCE = Room.databaseBuilder(
//                        context.applicationContext,
//                        HuzeRoomDatabase::class.java, "huze_database"
//                    )
//                        .build()
//                }
//            }
//            return INSTANCE as HuzeRoomDatabase
//        }
//
//    }
//}