package com.bangkitc23ps404.huze.ui.modelml

data class HasilModel(
    val predictedClass: String?,
    val confidence: Float?
)
