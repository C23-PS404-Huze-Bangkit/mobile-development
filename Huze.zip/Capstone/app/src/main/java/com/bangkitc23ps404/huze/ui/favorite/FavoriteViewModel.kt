package com.bangkitc23ps404.huze.ui.favorite

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.bangkitc23ps404.huze.data.Repository

class FavoriteViewModel(private val repository: Repository): ViewModel() {
 /*   suspend fun getDataHuze() = repository.getListHuze()*/
}