package com.bangkitc23ps404.huze.data.local.entity

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//@Entity(tableName = "huze")
//class HuzeEntity(
//    @NonNull
//    @field:PrimaryKey
//    @field:ColumnInfo(name = "ras")
//    var ras: String,
//    @field:ColumnInfo(name = "image")
//    var image: String
//)
