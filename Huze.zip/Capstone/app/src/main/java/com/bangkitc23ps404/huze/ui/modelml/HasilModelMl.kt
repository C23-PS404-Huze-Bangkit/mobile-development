package com.bangkitc23ps404.huze.ui.modelml

import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bangkitc23ps404.huze.databinding.ActivityHasilModelMlBinding
import java.io.File


class HasilModelMl : AppCompatActivity() {
    private lateinit var binding: ActivityHasilModelMlBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHasilModelMlBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val predictedClass = intent.getStringExtra("predictedClass")
        val confidence = intent.getFloatExtra("confidence", 0f)
        val filePath = intent.getStringExtra("filePath")

        if (filePath != null) {
            val imageFile = File(filePath)
            if (imageFile.exists()) {
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
                binding.ivHasilml.setImageBitmap(bitmap)
            }
        }

        setPredictedData(predictedClass, confidence.toString())
    }

    private fun setPredictedData(predictedClass: String?, confidence: String) {
        binding.predictedClassTextView.text = predictedClass
        binding.confidenceTextView.text = "Confidence: $confidence"
    }
}