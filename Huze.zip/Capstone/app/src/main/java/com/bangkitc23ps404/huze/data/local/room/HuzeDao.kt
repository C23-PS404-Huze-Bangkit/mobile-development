package com.bangkitc23ps404.huze.data.local.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


//@Dao
//interface HuzeDao {
//    @Insert(onConflict = OnConflictStrategy.IGNORE)
//    suspend fun insertHuze(huze: HuzeEntity)
//
//    @Query("SELECT * FROM huze")
//    suspend fun getListHuzeFavorite(): List<HuzeEntity>
//
//    @Query("DELETE FROM huze WHERE ras = :ras")
//    suspend fun deleteFavorite(ras: String)
//
//    @Query("SELECT EXISTS(SELECT * FROM huze where ras = :ras)")
//    suspend fun getHuzeFavorite(ras: String): Boolean
//}